package Farmsystem.abuse_children;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbuseChildrenApplicationTests {

	@Test
	void contextLoads() {
	}

}
