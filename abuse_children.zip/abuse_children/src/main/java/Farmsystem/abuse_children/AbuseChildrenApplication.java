package Farmsystem.abuse_children;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbuseChildrenApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbuseChildrenApplication.class, args);
	}

}
